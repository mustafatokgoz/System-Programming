#ifndef HELPER_H
#define HELPER_H

void exitInf(char*);
int open_file(char *filename);
int close_file(int fd);
#endif
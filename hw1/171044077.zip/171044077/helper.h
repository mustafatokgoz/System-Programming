#ifndef HELPER_H
#define HELPER_H

void errExit(char *);
void exitInf(char*);
int len(char *str);
#endif